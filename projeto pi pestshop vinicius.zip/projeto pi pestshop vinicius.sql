select * from tb_cliente;

alter table tb_cliente

alter column senha type varchar(20);