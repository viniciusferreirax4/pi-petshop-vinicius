package ete.pi.repositories;

import ete.pi.negocio.Usuario;
import ete.pi.database.ConexaoBanco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class RepUsuario {
    Connection con;
    public boolean inserir(Usuario usuario) throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        
        String sql = "insert into usuario (nome_cliente,"
                + "cpf_cliente,senha"
                + ") values"
                + "(?,?,md5(?))";
        
        try{
            con.setAutoCommit(false);
            PreparedStatement stmt = con.prepareStatement(sql);
            
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getSenha());
            stmt.setString(3, usuario.getCpf());
            
            stmt.execute();
            con.commit();
            JOptionPane.showMessageDialog(null, "Usu�rio salvo");
            ConexaoBanco.FecharConexao(con);
            
           
        }catch(Exception ex){
          try{
              con.rollback();
              System.err.println(ex.getMessage());
              return false;
              
          }catch(SQLException exSql){
              System.err.println(exSql.getMessage());
          }
        }   
         return true;
    }
    public List<Usuario> retornar()throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        List<Usuario> usuarios = new ArrayList<>();
        
        String sql = "select * from usuario order by id desc";
        
        try{
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                
                Usuario usuario = new Usuario();
                
                usuario.setId(rs.getInt("id"));
                usuario.setNome(rs.getString("nome_cliente"));
                usuario.setCpf(rs.getString("cpf_cliente"));
                usuario.setSenha(rs.getString("senha"));
                usuarios.add(usuario);
            }
        }catch(SQLException ex){
            return null;
        }
        ConexaoBanco.fecharConexao(con);
        
        return usuarios;
    }
     public Usuario achar(String cpf)throws SQLException{
        
        con = (Connection) ConexaoBanco.conectar();
        Usuario usuario = new Usuario();
        
        String sql = "select * from usuario where cpf_cliente = '" + cpf +"'";
     
        
        try{
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                
                usuario.setId(rs.getInt("id"));
                usuario.setNome(rs.getString("nome_cliente"));
                usuario.setCpf(rs.getString("cpf_cliente"));
                usuario.setSenha(rs.getString("senha"));
               
            }
            ConexaoBanco.FecharConexao(con);
        }catch(SQLException ex){
            return null;
        }
        
        return usuario;
    }
     public boolean atualizar(Usuario usuario)throws SQLException {
         
         con = (Connection) ConexaoBanco.conectar();
         String sql = "update aluno set senha = md5(?), "
                 + "endereco = ?, fone = ? where id = ?";
         try{
             con.setAutoCommit(false);
             PreparedStatement stmt = con.prepareStatement(sql);
             
             stmt.setString(1, usuario.getSenha());
             stmt.setString(2, usuario.getEndereco());
             stmt.setString(3, usuario.getFone());
             stmt.setInt(4, usuario.getId());
             
             stmt.execute();
             
             con.commit();
             ConexaoBanco.FecharConexao(con);
             
             return true;
         }catch (SQLException ex) {
             try {
                 con.rollback();
                 System.err.println(ex);
                 return false;
             }catch (SQLException ex1) {
                 System.err.println(ex1);
             }
             return false;
         }
     }
     public boolean excluir(int id)throws SQLException {
         con = (Connection) ConexaoBanco.conectar();
         String sql = "delete from aluno where id = ?";
         
         try{
             
             con.setAutoCommit(false);
             PreparedStatement stmt = con.prepareStatement(sql);
             
             stmt.setInt(1, id);
             
             stmt.execute();
             con.commit();
             ConexaoBanco.FecharConexao(con);
             return true;
         }catch(SQLException ex){
             return false;
         }
     }
     public int login(String cpf, String senha)throws SQLException{
         
         con = (Connection) ConexaoBanco.conectar();
         int ret = 0;
         PreparedStatement stmt = null;
         
         String sql = "select count(*) as total from tb_cliente where cpf_cliente ='"+cpf+"' and senha = md5('"+senha+"') ";
         
         
         try{
             
             stmt = con.prepareStatement(sql);
             stmt.setString(1, cpf);
             stmt.setString(2, senha);
             ResultSet rs = stmt.executeQuery(sql);
             
             while(rs.next()){
                 ret = rs.getInt("total");
             }
         }catch(SQLException ex){
       
             ConexaoBanco.FecharConexao(con);
             return ret;
         }
        return 0;
     }
     
}

