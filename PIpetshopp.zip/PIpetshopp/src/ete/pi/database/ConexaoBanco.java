
package ete.pi.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ConexaoBanco {
    
    private static final String URL = "jdbc:postgresql://localhost:5432/ProjetoPIpetshop";
    private static final String USUARIO = "postgres";
    private static final String SENHA = "teste";
    


public static Connection conectar() throws SQLException {
try{
Class.forName("org.postgresql.Driver");
} catch (ClassNotFoundException e) {
JOptionPane.showMessageDialog(null, "erro ao carregar driver");
throw new SQLException("Driver do postgreSQL n�o encontrado. "
+ "Certifique-se de que o driver est� no classpath. ", e);
}
return DriverManager.getConnection(URL, USUARIO, SENHA);
}

public static void FecharConexao(Connection conexao){
    if (conexao != null){
        try{
            if (!conexao.isClosed()){
                conexao.close();
            }
        }catch (SQLException e){
            
            System.err.println("Erro ao fechar conex�o com o banco de dados: "
            + e.getMessage());
        }
}
}

    public static void fecharConexao(Connection con) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}